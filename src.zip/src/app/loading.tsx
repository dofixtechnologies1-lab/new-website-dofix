import PreLoader from "@/components/Common/PreLoader";

export default function Loading() {
  return <PreLoader />;
}