import Painting from "@/components/Painting";

// import { Metadata } from "next";
// export const metadata: Metadata = {
//   title: "Dofix Technologies Pvt Ltd",
//   description: "This is Service Page for Dofix",
//   // other metadata
// };

const PaintingPage = () => {
  return (
    <main>
      <Painting />
    </main>
  );
};

export default PaintingPage;