import shopData from "@/components/Shop/shopData";
import Link from "next/link";

export default function SubCategoryPage({
  params,
}: {
  params: { category: string; subcategory: string };
}) {
  const { category, subcategory } = params;

  const filteredServices = shopData.filter(
    (item) =>
      item.category === category &&
      item.subCategory === subcategory
  );

  if (filteredServices.length === 0) {
    return (
      <div className="p-20 text-center text-red-600 text-xl">
        No Services Found
      </div>
    );
  }

  return (
    <div className="max-w-[900px] mx-auto py-16 space-y-6">
      {filteredServices.map((service) => (
        <div
          key={service.id}
          className="bg-white shadow-md rounded-xl p-6 border"
        >
          <h2 className="text-xl font-semibold">
            {service.title}
          </h2>

          <p className="text-gray-500 mt-2">
            {service.variants.length} Options Available
          </p>

          <Link
            href={`/ac-services/${service.id}`}
            className="text-blue-600 mt-4 inline-block"
          >
            View Details →
          </Link>
        </div>
      ))}
    </div>
  );
}