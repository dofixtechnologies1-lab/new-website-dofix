import Interior from "@/components/Interior";

// import { Metadata } from "next";
// export const metadata: Metadata = {
//   title: "Dofix Technologies Pvt Ltd",
//   description: "This is Service Page for Dofix",
//   // other metadata
// };

const InteriorPage = () => {
  return (
    <main>
      <Interior />
    </main>
  );
};

export default InteriorPage;