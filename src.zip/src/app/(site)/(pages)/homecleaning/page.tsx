import HomeCleaning from "@/components/HomeCleaning";

// import { Metadata } from "next";
// export const metadata: Metadata = {
//   title: "Dofix Technologies Pvt Ltd",
//   description: "This is Home Cleaning Page for Dofix",
//   // other metadata
// };

const HomeCleaningPage = () => {
  return (
    <main>
      <HomeCleaning />
    </main>
  );
};

export default HomeCleaningPage;