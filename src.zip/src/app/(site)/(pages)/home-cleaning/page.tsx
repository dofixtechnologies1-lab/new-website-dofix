"use client";

import { useRouter } from "next/navigation";
import homeCleaningData from "@/components/Shop/homeCleaningData";

export default function HomeCleaningPage() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-gray-100 py-12 px-4">
      <div className="max-w-[900px] mx-auto space-y-6">

        {homeCleaningData.map((service) => (
          <div
            key={service.id}
            onClick={() => router.push(`/home-cleaning/${service.id}`)}
            className="cursor-pointer bg-white rounded-3xl shadow-md p-6 flex gap-6 hover:shadow-lg transition"
          >
            <div className="w-40 h-40 rounded-2xl overflow-hidden">
              <img
                src={service.imgs.thumbnails[0]}
                alt={service.title}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="flex flex-col justify-center">
              <h3 className="text-xl font-semibold">
                {service.title}
              </h3>

              <p className="text-sm text-gray-500 mt-2">
                {service.variants.length} Options Available
              </p>

              <span className="text-[#3683ab] mt-3 font-medium">
                View Details →
              </span>
            </div>
          </div>
        ))}

      </div>
    </div>
  );
}