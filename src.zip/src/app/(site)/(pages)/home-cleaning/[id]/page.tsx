"use client";

import { useParams, useRouter } from "next/navigation";
import { useAppDispatch, useAppSelector } from "@/redux/hooks";
import {
  addItemToCart,
  selectCartItems,
  selectTotalPrice,
} from "@/redux/features/cart-slice";
import homeCleaningData from "@/components/Shop/homeCleaningData";

export default function VariantPage() {
  const params = useParams();
  const router = useRouter();
  const dispatch = useAppDispatch();

  const id = Number(params.id);
  const service = homeCleaningData.find((s) => s.id === id);

  const cartItems = useAppSelector(selectCartItems);
  const totalPrice = useAppSelector(selectTotalPrice);

  if (!service) return <div>Service Not Found</div>;

  const handleAdd = (variant: any) => {
    dispatch(
      addItemToCart({
        id: variant.id,
        title: variant.name,
        price: variant.price,
        discountedPrice: variant.discountedPrice,
        quantity: 1,
        imgs: {
          thumbnails: [variant.image],
          previews: [variant.image],
        },
      })
    );
  };

  const getItemQuantity = (variantId: number) => {
    const item = cartItems.find((item) => item.id === variantId);
    return item ? item.quantity : 0;
  };

return (
  <div className="min-h-screen bg-gray-100 pb-32 pt-45">

    <div className="w-full px-4 md:px-8 lg:px-12 py-8">

      <h2 className="text-3xl font-bold mb-8">
        {service.title}
      </h2>

      {/* Responsive Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">

        {service.variants.map((variant) => {
          const quantity = getItemQuantity(variant.id);

          return (
            <div
              key={variant.id}
              className="bg-white rounded-3xl shadow-md p-6 hover:shadow-xl transition"
            >

              {/* Top Section */}
              <div className="flex justify-between items-start mb-4">

                {/* Image */}
                <div className="w-32 h-24 rounded-2xl overflow-hidden bg-gray-100">
                  <img
                    src={variant.image}
                    alt={variant.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Add Button */}
                <button
                  onClick={() => handleAdd(variant)}
                  className="bg-[#3683ab] text-white px-6 py-2 rounded-xl font-medium hover:bg-[#2f7396] transition"
                >
                  {quantity > 0 ? `Added (${quantity})` : "Add"}
                </button>

              </div>

              {/* Title */}
              <h3 className="text-lg font-semibold">
                {variant.name}
              </h3>

              {/* Rating */}
              <div className="flex items-center gap-2 mt-2 text-sm text-gray-600">
                <span className="text-yellow-500">⭐</span>
                4.8 <span>(20 Reviews)</span>
              </div>

              {/* Price */}
              <div className="mt-2">
                <span className="text-xl font-bold">
                  ₹{variant.discountedPrice}
                </span>
                <span className="ml-3 text-gray-400 line-through">
                  ₹{variant.price}
                </span>
              </div>

              {/* Description */}
              <p className="text-sm text-gray-500 mt-3">
                Dofix offers professional cleaning services for
                residential and commercial spaces.
              </p>

              {/* Links */}
              <div className="flex justify-between mt-4 text-sm">
                <span className="text-yellow-600 italic cursor-pointer">
                  The Dofix Rate Card
                </span>
                <span className="text-blue-600 underline cursor-pointer">
                  View Rate Card
                </span>
              </div>

            </div>
          );
        })}

      </div>
    </div>

    {/* Sticky Bottom Cart */}
    {cartItems.length > 0 && (
      <div className="fixed bottom-4 left-0 right-0 flex justify-center">
        <div className="bg-[#3683ab] text-white w-[90%] max-w-[650px] rounded-2xl px-6 py-4 flex justify-between items-center shadow-lg">

          <div>
            <p className="text-sm">
              {cartItems.length} item in cart
            </p>
            <p className="text-xl font-bold">
              ₹{totalPrice}
            </p>
          </div>

          <button
            onClick={() => router.push("/cart")}
            className="bg-white text-[#3683ab] px-6 py-2 rounded-xl font-semibold"
          >
            View Cart
          </button>

        </div>
      </div>
    )}

  </div>
);
}