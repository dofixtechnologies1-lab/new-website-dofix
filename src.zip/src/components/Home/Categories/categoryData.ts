const data = [
  {
    title: "Ac Repair Installation",
    id: 1,
    img: "/images/categories/categories-ac.png",
    link: "acrepairinstallation"
  },
  {
    title: "Home Cleaning",
    id: 2,
    img: "/images/categories/categories-hc.png",
    link: "home-cleaning",
  },
  {
    title: "Home Appliances",
    id: 3,
    img: "/images/categories/categories-re.png",
    link: "home-appliances",
  },
  {
    title: "Interior",
    id: 4,
    img: "/images/categories/categories-in.png",
    link: "interior",
  },
  {
    title: "Painting",
    id: 5,
    img: "/images/categories/categories-pa.png",
    link: "painting",
  },
  {
    title: "Electrician",
    id: 6,
    img: "/images/categories/categories-el.png",
    link: "electrician",
  },
];

export default data;