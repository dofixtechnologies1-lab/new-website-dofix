export type Service = {
  title: string;
  id: number;
  img: string;
};
