export type BlogItem = {
  date: string;
  views: number;
  title: string;
  img: string;
};
